# Resource measurement notes

The repository distinguishes measured resource data from claims that remain unsupported.

## Measured when available

- End-to-end wall time for monitored stages.
- Test throughput and instance/GPU-hours derived from measured wall time.
- Peak process-tree RAM using RSS.
- Peak process GPU VRAM using NVIDIA process accounting.
- Peak total GPU memory used during the stage.
- Approximate whole-GPU energy from `nvidia-smi` power telemetry.
- Fine-tuned checkpoint storage size.
- Parameter count for each fine-tuned head.
- Fine-tuned training time and test inference time.

The supervised reference for each encoder uses **two independently fine-tuned checkpoints**:
one DISEASE model and one CHEMICAL model. Training time and checkpoint storage are summed
across the two heads. Peak RAM/VRAM is the maximum sequential peak because the current
implementation loads the two heads one at a time.

## Cached MedGemma handling

MedGemma zero-shot and selective-routing outputs may already exist in the Ollama decision
cache. A cached replay can finish in seconds even though the original LLM inference took
minutes or hours. **Cached replay wall time is never used as MedGemma inference cost.**

For MedGemma, runtime and cost calculations use the original per-request durations stored
inside the zero-shot or tie-break cache summaries. If MedGemma was not rerun fresh, RAM,
VRAM, total GPU-memory peak, and energy are reported as not measured rather than copied
from the cached replay.

For hybrid methods, the runtime/cost basis combines freshly monitored conventional-pipeline
wall time with the original saved MedGemma request durations. Full hybrid RAM/VRAM/energy
is left unreported unless fresh LLM inference is performed.

## Important limits

The GPU energy value is system-level telemetry and is not process-isolated. It should be
treated as an approximate diagnostic, not a precision energy benchmark.

Peak memory is measured for the actual sequential implementation. It is not an estimate of
memory required if all models were loaded concurrently.

The repository does not claim FLOPs, carbon emissions, or universal deployment cost.

## Cloud-cost calculation

`cloud_cost_inputs.csv` always contains the measured instance-hours needed for the observed
test run and the normalised instance-hours per 1,000 documents.

The repository includes a dated representative public on-demand single-GPU rate range
checked on 2026-10-13. The references are Google Cloud g2-standard-4 and g2-standard-8
with NVIDIA L4 GPUs and AWS g5.xlarge with an NVIDIA A10G GPU. These are practical
single-GPU cloud references capable of the workload, not hardware-equivalent replacements
for the local RTX 3070 Ti.

The default report therefore gives a low, middle, and high approximate compute-only cost
by multiplying measured instance-hours by the reference rates. The reference prices are
stored in `reference_cloud_gpu_rates.csv` with provider, instance, GPU, date, and source.

An optional current provider-specific rate can still be supplied:

```cmd
set CLOUD_INSTANCE_HOURLY_USD=YOUR_CURRENT_INSTANCE_PRICE
RUN_ALL.cmd
```

Cloud estimates exclude storage, data transfer, idle/startup time, taxes, discounts, spot
pricing, reservations, and provider-specific billing rules.
