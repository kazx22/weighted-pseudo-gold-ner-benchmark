Canonical symmetric reporting outputs. BC5CDR and BioRED official use the same table/figure families. BioRED overlap-excluded is the separate sensitivity branch.
