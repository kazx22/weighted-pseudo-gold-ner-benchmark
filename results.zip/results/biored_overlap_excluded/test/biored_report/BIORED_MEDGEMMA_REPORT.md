# BioRED MedGemma Report — test

Task scope: BioRED DiseaseOrPhenotypicFeature and ChemicalEntity only.

## Main result

- Weighted pseudo-gold F1: 0.6649
- MedGemma zero-shot F1: 0.2622
- Weighted + MedGemma F1: 0.6714
- Hybrid minus weighted F1: +0.006478

## Routing

- Total candidates: 6,530
- Routed to MedGemma: 31
- Routing rate: 0.47%
- Tie-break request time: 1.6 minutes
- Full zero-shot request time: 32.4 minutes

## Routed-candidate exact-gold audit

- Correct accepts: 21
- False accepts: 5
- Correct rejects: 4
- False rejects: 1
- Acceptance precision: 80.77%
- Rejection specificity: 44.44%

BIO confusion matrices are secondary diagnostics. The primary metric remains exact character span + label.

No Ollama or MedGemma inference was run by this report script.
