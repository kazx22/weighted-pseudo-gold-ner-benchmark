# BioRED MedGemma Report — test

Task scope: BioRED DiseaseOrPhenotypicFeature and ChemicalEntity only.

## Main result

- Weighted pseudo-gold F1: 0.7466
- MedGemma zero-shot F1: 0.2622
- Weighted + MedGemma F1: 0.7476
- Hybrid minus weighted F1: +0.001038

## Routing

- Total candidates: 5,173
- Routed to MedGemma: 32
- Routing rate: 0.62%
- Tie-break request time: 1.7 minutes
- Full zero-shot request time: 32.6 minutes

## Routed-candidate exact-gold audit

- Correct accepts: 17
- False accepts: 11
- Correct rejects: 4
- False rejects: 0
- Acceptance precision: 60.71%
- Rejection specificity: 26.67%

BIO confusion matrices are secondary diagnostics. The primary metric remains exact character span + label.

No Ollama or MedGemma inference was run by this report script.
