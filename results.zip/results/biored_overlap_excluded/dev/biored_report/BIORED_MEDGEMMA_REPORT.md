# BioRED MedGemma Report — dev

Task scope: BioRED DiseaseOrPhenotypicFeature and ChemicalEntity only.

## Main result

- Weighted pseudo-gold F1: 0.6711
- MedGemma zero-shot F1: 0.2551
- Weighted + MedGemma F1: 0.6733
- Hybrid minus weighted F1: +0.002197

## Routing

- Total candidates: 6,235
- Routed to MedGemma: 20
- Routing rate: 0.32%
- Tie-break request time: 1.1 minutes
- Full zero-shot request time: 33.1 minutes

## Routed-candidate exact-gold audit

- Correct accepts: 10
- False accepts: 5
- Correct rejects: 5
- False rejects: 0
- Acceptance precision: 66.67%
- Rejection specificity: 50.00%

BIO confusion matrices are secondary diagnostics. The primary metric remains exact character span + label.

No Ollama or MedGemma inference was run by this report script.
