# BioRED MedGemma Report — dev

Task scope: BioRED DiseaseOrPhenotypicFeature and ChemicalEntity only.

## Main result

- Weighted pseudo-gold F1: 0.7311
- MedGemma zero-shot F1: 0.2551
- Weighted + MedGemma F1: 0.7294
- Hybrid minus weighted F1: -0.001668

## Routing

- Total candidates: 5,025
- Routed to MedGemma: 33
- Routing rate: 0.66%
- Tie-break request time: 1.7 minutes
- Full zero-shot request time: 33.3 minutes

## Routed-candidate exact-gold audit

- Correct accepts: 21
- False accepts: 9
- Correct rejects: 2
- False rejects: 1
- Acceptance precision: 70.00%
- Rejection specificity: 18.18%

BIO confusion matrices are secondary diagnostics. The primary metric remains exact character span + label.

No Ollama or MedGemma inference was run by this report script.
