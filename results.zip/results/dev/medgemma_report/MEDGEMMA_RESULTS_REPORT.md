# MedGemma BC5CDR Post-processing Report — dev

This report was generated from saved outputs. No Ollama or MedGemma inference was rerun.

## Main exact-span results

| System | Precision | Recall | F1 | TP | FP | FN |
|---|---:|---:|---:|---:|---:|---:|
| Majority Pseudo-Gold | 0.9550 | 0.5618 | 0.7074 | 5,388 | 254 | 4,203 |
| Weighted Pseudo-Gold | 0.9589 | 0.6886 | 0.8016 | 6,604 | 283 | 2,987 |
| scispaCy | 0.8098 | 0.7153 | 0.7596 | 6,860 | 1,611 | 2,731 |
| MedGemma Zero-Shot | 0.5947 | 0.3039 | 0.4023 | 2,915 | 1,987 | 6,676 |
| Weighted + MedGemma Tie-Breaker | 0.9577 | 0.6920 | 0.8035 | 6,637 | 293 | 2,954 |

## Central finding

The selective MedGemma tie-breaker changed F1 from 0.801554 to 0.803462, a difference of 0.001909.
It added 33 true positives and 10 false positives, while changing false negatives by -33.
Precision changed by -0.001188 and recall changed by 0.003441.

## Per-label effect

- DISEASE F1: 0.7885 → 0.7937 (0.005180).
- CHEMICAL F1: 0.8119 → 0.8113 (-0.000660).

## Zero-shot MedGemma

MedGemma zero-shot achieved precision 0.5947, recall 0.3039, and F1 0.4023. scispaCy F1 was 0.7596.
Of 7,767 accepted extraction outputs before final deduplication, only 8 arrived with already correct offsets. The pipeline repaired 7,759 offsets by matching returned text back to the source.
Unmapped outputs: 35; ambiguous repeated occurrences: 2.

## Hybrid routing and cost

The pipeline routed 658 of 46,161 candidates to MedGemma (1.43%).
MedGemma accepted 595 routed candidates and rejected 63.
Selective tie-breaking used 32.1 minutes of LLM request time, compared with 137.7 minutes for full zero-shot extraction on the same split. This is approximately 76.68% less LLM request time.

## Routed-candidate audit against exact human gold

- Correct accepts (TP): 458.
- False accepts (FP): 137.
- Correct rejects (TN): 54.
- False rejects (FN): 9.
- Acceptance precision: 76.97%.
- Acceptance recall: 98.07%.
- Rejection specificity: 28.27%.

## Important adverse observations

1. The hybrid did not improve held-out exact-span F1. Its tiny negative difference from the weighted baseline was not significant.
2. The tie-breaker was permissive: it accepted many correct candidates, but it also accepted false candidates and rejected relatively few false ones.
3. Disease-label decisions were less reliable than chemical-label decisions. Medically plausible symptoms or conditions can still be false positives relative to the BC5CDR annotation policy.
4. MedGemma did not reliably supply exact character offsets. Text-to-source offset repair was essential and must be reported in the methodology.
5. Zero-shot extraction used 450-character segments to prevent repetitive generation and truncated JSON. This segmentation can reduce broader context and should be listed as a limitation.

## Safe paper interpretation

The result supports the cost-saving part of the architecture but not an accuracy-improvement claim. Selective routing processed only a small fraction of candidates and reduced LLM runtime, yet the current MedGemma adjudicator did not significantly outperform the encoder-only weighted ensemble. The negative result should be reported directly rather than described as an improvement.

## Generated figures

- `figures/medgemma_exact_span_comparison.png`
- `figures/medgemma_per_label_f1.png`
- `figures/medgemma_routing.png`
- `figures/cm_medgemma_zero_shot_bio.png`
- `figures/cm_medgemma_hybrid_bio.png`
