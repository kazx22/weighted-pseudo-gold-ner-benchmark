# MedGemma BC5CDR Post-processing Report — dev

This report was generated from saved outputs. No Ollama or MedGemma inference was rerun.

## Main exact-span results

| System | Precision | Recall | F1 | TP | FP | FN |
|---|---:|---:|---:|---:|---:|---:|
| Majority Pseudo-Gold | 0.9417 | 0.5627 | 0.7045 | 5,397 | 334 | 4,194 |
| Weighted Pseudo-Gold | 0.9082 | 0.7984 | 0.8497 | 7,657 | 774 | 1,934 |
| scispaCy | 0.8098 | 0.7153 | 0.7596 | 6,860 | 1,611 | 2,731 |
| MedGemma Zero-Shot | 0.5943 | 0.3017 | 0.4002 | 2,894 | 1,976 | 6,697 |
| Weighted + MedGemma Tie-Breaker | 0.9097 | 0.7979 | 0.8501 | 7,653 | 760 | 1,938 |

## Central finding

The selective MedGemma tie-breaker changed F1 from 0.849739 to 0.850144, a difference of 0.000405.
It added -4 true positives and -14 false positives, while changing false negatives by 4.
Precision changed by 0.001468 and recall changed by -0.000417.

## Per-label effect

- DISEASE F1: 0.8170 → 0.8174 (0.000423).
- CHEMICAL F1: 0.8755 → 0.8759 (0.000385).

## Zero-shot MedGemma

MedGemma zero-shot achieved precision 0.5943, recall 0.3017, and F1 0.4002. scispaCy F1 was 0.7596.
Of 7,656 accepted extraction outputs before final deduplication, only 8 arrived with already correct offsets. The pipeline repaired 7,648 offsets by matching returned text back to the source.
Unmapped outputs: 34; ambiguous repeated occurrences: 2.

## Hybrid routing and cost

The pipeline routed 334 of 40,860 candidates to MedGemma (0.82%).
MedGemma accepted 252 routed candidates and rejected 82.
Selective tie-breaking used 16.9 minutes of LLM request time, compared with 151.0 minutes for full zero-shot extraction on the same split. This is approximately 88.81% less LLM request time.

## Routed-candidate audit against exact human gold

- Correct accepts (TP): 169.
- False accepts (FP): 83.
- Correct rejects (TN): 73.
- False rejects (FN): 9.
- Acceptance precision: 67.06%.
- Acceptance recall: 94.94%.
- Rejection specificity: 46.79%.

## Important adverse observations

1. The hybrid did not improve held-out exact-span F1. Its tiny negative difference from the weighted baseline was not significant.
2. The tie-breaker was permissive: it accepted many correct candidates, but it also accepted false candidates and rejected relatively few false ones.
3. Disease-label decisions were less reliable than chemical-label decisions. Medically plausible symptoms or conditions can still be false positives relative to the BC5CDR annotation policy.
4. MedGemma did not reliably supply exact character offsets. Text-to-source offset repair was essential and must be reported in the methodology.
5. Zero-shot extraction used 450-character segments to prevent repetitive generation and truncated JSON. This segmentation can reduce broader context and should be listed as a limitation.
6. Examples of false accepted fragments included: `Flu`, `flu`, `met`, `az`, `T`.

## Safe paper interpretation

The result supports the cost-saving part of the architecture but not an accuracy-improvement claim. Selective routing processed only a small fraction of candidates and reduced LLM runtime, yet the current MedGemma adjudicator did not significantly outperform the encoder-only weighted ensemble. The negative result should be reported directly rather than described as an improvement.

## Generated figures

- `figures/medgemma_exact_span_comparison.png`
- `figures/medgemma_per_label_f1.png`
- `figures/medgemma_routing.png`
- `figures/cm_medgemma_zero_shot_bio.png`
- `figures/cm_medgemma_hybrid_bio.png`
