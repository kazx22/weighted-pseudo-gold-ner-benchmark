# BioRED overlap sensitivity comparison

Official BioRED test: 100 documents.
Overlap-excluded BioRED test: 66 documents (34 BC5CDR-overlapping documents removed).

| Metric | Official | Overlap-excluded |
|---|---:|---:|
| Majority F1 | 0.6721 | 0.6671 |
| Weighted F1 | 0.7867 | 0.7466 |
| CAWV F1 | 0.7967 | 0.7434 |
| CAWV - WV | 0.0100 | -0.0032 |
| scispaCy F1 | 0.6472 | 0.5557 |
| Tuned unweighted F1 | 0.7390 | 0.7034 |
| MedGemma zero-shot F1 | 0.3424 | 0.2622 |
| Weighted + MedGemma F1 | 0.7845 | 0.7476 |
| 25% dev-gold mean weighted F1 | 0.7826 | 0.7431 |
| 50% dev-gold mean weighted F1 | 0.7830 | 0.7412 |
| 75% dev-gold mean weighted F1 | 0.7860 | 0.7432 |
| 100% dev-gold weighted F1 | 0.7867 | 0.7466 |

The overlap-excluded branch is recalibrated independently on its cleaned development split; official BioRED results are retained rather than replaced.
