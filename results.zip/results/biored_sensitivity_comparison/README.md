# BioRED overlap sensitivity comparison

Official BioRED test: 100 documents.
Overlap-excluded BioRED test: 66 documents (34 BC5CDR-overlapping documents removed).

| Metric | Official | Overlap-excluded |
|---|---:|---:|
| Majority F1 | 0.6463 | 0.6244 |
| Weighted F1 | 0.7211 | 0.6649 |
| scispaCy F1 | 0.6472 | 0.5557 |
| Tuned unweighted F1 | 0.6463 | 0.6244 |
| MedGemma zero-shot F1 | 0.3424 | 0.2622 |
| Weighted + MedGemma F1 | 0.6614 | 0.6714 |
| 25% dev-gold mean weighted F1 | 0.7211 | 0.6602 |
| 50% dev-gold mean weighted F1 | 0.7201 | 0.6616 |
| 75% dev-gold mean weighted F1 | 0.7211 | 0.6666 |
| 100% dev-gold weighted F1 | 0.7211 | 0.6649 |

The overlap-excluded branch is recalibrated independently on its cleaned development split; official BioRED results are retained rather than replaced.
