# BioRED conventional overlap-sensitivity comparison

Official: 100 dev / 100 test documents.
Overlap-excluded: 68 dev / 66 test documents.
Removed: 32 dev and 34 test documents shared with BC5CDR.

| Metric | Official | Overlap-excluded |
|---|---:|---:|
| Majority F1 | 0.6463 | 0.6244 |
| Weighted F1 | 0.7211 | 0.6649 |
| scispaCy F1 | 0.6472 | 0.5557 |
| Tuned unweighted F1 | 0.6463 | 0.6244 |
| 25% dev-gold mean weighted F1 | 0.7211 | 0.6602 |
| 50% dev-gold mean weighted F1 | 0.7201 | 0.6616 |
| 75% dev-gold mean weighted F1 | 0.7211 | 0.6666 |
| 100% dev-gold weighted F1 | 0.7211 | 0.6649 |

The overlap-excluded branch has its own development-fitted weights and threshold; it does not reuse the official BioRED calibration.
