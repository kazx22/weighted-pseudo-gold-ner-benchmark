# BioRED conventional overlap-sensitivity comparison

Official: 100 dev / 100 test documents.
Overlap-excluded: 68 dev / 66 test documents.
Removed: 32 dev and 34 test documents shared with BC5CDR.

| Metric | Official | Overlap-excluded |
|---|---:|---:|
| Majority F1 | 0.6721 | 0.6671 |
| Weighted F1 | 0.7867 | 0.7466 |
| CAWV F1 | 0.7967 | 0.7434 |
| CAWV - WV | +0.0100 | -0.0032 |
| CAWV vs WV Holm p | 0.0040 | 0.5235 |
| scispaCy F1 | 0.6472 | 0.5557 |
| Tuned unweighted F1 | 0.7390 | 0.7034 |
| 25% dev-gold mean weighted F1 | 0.7826 | 0.7431 |
| 50% dev-gold mean weighted F1 | 0.7830 | 0.7412 |
| 75% dev-gold mean weighted F1 | 0.7860 | 0.7432 |
| 100% dev-gold weighted F1 | 0.7867 | 0.7466 |

The overlap-excluded branch has its own development-fitted weights and threshold; it does not reuse the official BioRED calibration.
